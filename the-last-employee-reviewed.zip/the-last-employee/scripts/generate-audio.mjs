// Generates ALL audio for THE LAST EMPLOYEE with zero dependencies (Node only) + ffmpeg for the voice:
//   public/audio/fx.wav         procedural score + SFX (drone, ambience, footsteps, buzz, interference,
//                               pulses, riser, impacts, sudden silence 70.5-74.4 s, final-message ticks)
//   public/audio/narration.wav  synthesized narration (ffmpeg 'flite' TTS, pitched down + reverb),
//                               timed to src/audio/narration.mjs
// Everything is original / synthesized, so there are no licensing issues.
// Usage: node scripts/generate-audio.mjs
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { footstepTimes } from "../src/path.mjs";
import { CUES } from "../src/audio/narration.mjs";

const SR = 44100, DUR = 85, N = SR * DUR;
const L = new Float32Array(N), R = new Float32Array(N);
const TAU = Math.PI * 2;
let seed = 1234567;
const rand = () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const noise = () => rand() * 2 - 1;
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const smooth = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
const SILENCE = [70.45, 74.38]; // sudden silence during the reveal (kept in sync with the video)

function add(t0, dur, fn, pan = 0) {
  const s0 = Math.floor(t0 * SR), n = Math.floor(dur * SR);
  const gl = Math.cos((pan + 1) * Math.PI / 4), gr = Math.sin((pan + 1) * Math.PI / 4);
  for (let i = 0; i < n && s0 + i < N; i++) {
    if (s0 + i < 0) continue;
    const v = fn(i / SR, i);
    L[s0 + i] += v * gl; R[s0 + i] += v * gr;
  }
}
function reverbTap(t0, dur, fn, pan, tails = [[0.07, 0.3], [0.16, 0.16], [0.31, 0.08]]) {
  add(t0, dur, fn, pan);
  for (const [d, g] of tails) add(t0 + d, dur, (t, i) => fn(t, i) * g, -pan * 0.6);
}
const lp = (a) => { let y = 0; return (x) => (y += a * (x - y)); };

// ---------------------------------------------------------------- continuous layers
{
  const n1 = lp(0.02), n2 = lp(0.02), n3 = lp(0.2), n4 = lp(0.2);
  for (let i = 0; i < N; i++) {
    const t = i / SR;
    const inSil = t > SILENCE[0] && t < SILENCE[1];
    // distant (muffled) until the camera passes through the glass at ~10.2 s
    const near = 0.35 + 0.65 * smooth((t - 9.8) / 1.6);
    // drone: sub + detuned fifths, growing darker/larger toward the reveal
    const grow = 0.55 + 0.9 * smooth(t / 60);
    const lfo = Math.sin(TAU * 0.07 * t);
    let drone = Math.sin(TAU * 41.2 * t) * 0.55 + Math.sin(TAU * 55 * t + lfo * 1.6) * 0.32 + Math.sin(TAU * 82.4 * t * (1 + 0.0015 * lfo)) * 0.2 + Math.sin(TAU * 61.7 * t) * 0.12 * smooth((t - 38) / 8);
    drone *= 0.17 * grow * smooth(t / 3);
    // office ambience: HVAC rumble + mains hum
    const hvac = n1(noise()) * 7 * 0.05 + n2(noise()) * 6 * 0.03;
    const hum = (Math.sin(TAU * 50 * t) * 0.012 + Math.sin(TAU * 100 * t) * 0.008 + Math.sin(TAU * 150 * t) * 0.004) * near;
    const amb = (hvac * near + hum) * smooth(t / 2);
    let v = drone + amb;
    if (t > 74.38) {
      // after the blackout: a thin electronic tone
      const e = smooth((t - 75.2) / 2.5) * (1 - smooth((t - 83.4) / 1.4));
      v = Math.sin(TAU * 110 * t) * 0.05 * e * (0.7 + 0.3 * Math.sin(TAU * 0.4 * t)) + Math.sin(TAU * 164.8 * t) * 0.03 * e + Math.sin(TAU * 440 * t) * 0.006 * e * (Math.sin(TAU * 6 * t) > 0.6 ? 1 : 0);
    }
    if (inSil) v = 0;
    L[i] += v * 1.0; R[i] += v * (0.96 + 0.04 * Math.sin(t * 0.3));
  }
}

// ---------------------------------------------------------------- riser (49 -> 70.4 s)
{
  let ph = 0, ph2 = 0;
  const nb = lp(0.3);
  for (let t = 49; t < 70.4; t += 1 / SR) {
    const u = (t - 49) / 21.4, i = Math.floor(t * SR);
    const f = 70 * Math.pow(9, u);
    ph += TAU * f / SR; ph2 += TAU * f * 1.007 / SR;
    const amp = 0.17 * u * u * u + 0.01;
    const tone = (Math.sin(ph) + Math.sin(ph2)) * 0.5 + 0.35 * Math.sin(ph * 2);
    const hiss = nb(noise()) * 0.5 * u * u;
    const end = 1 - smooth((t - 70.3) / 0.1);
    const v = (tone * amp + hiss * 0.15) * end;
    L[i] += v; R[i] += v * 0.97;
  }
}

// ---------------------------------------------------------------- footsteps (synced to the walk cycle)
{
  const steps = footstepTimes();
  steps.forEach((ts, k) => {
    const side = k % 2 ? 1 : -1;
    const gain = ts < 12 ? 0.55 : 1;
    const pan = side * 0.25;
    reverbTap(ts, 0.35, (t) => {
      const thud = Math.sin(TAU * (95 - 40 * t) * t) * Math.exp(-t * 28) * 0.55;
      const tap = noise() * Math.exp(-t * 160) * 0.35;
      const click = Math.sin(TAU * 1900 * t) * Math.exp(-t * 400) * 0.12;
      return (thud + tap + click) * 0.45 * gain;
    }, pan);
  });
}

// ---------------------------------------------------------------- electrical buzz + relay thunks as lights die
const OFF = [41.0, 42.4, 43.8, 45.2, 46.8, 48.4];
OFF.forEach((o, i) => {
  add(o - 0.6, 0.9, (t) => {
    const on = Math.sin(TAU * 17 * t) > -0.2 + 0.5 * Math.sin(t * 40 + i) ? 1 : 0.2;
    const saw = ((t * (120 + i * 8)) % 1) * 2 - 1;
    return saw * on * 0.16 * (1 - smooth((t - 0.6) / 0.25)) * (Math.sin(TAU * 100 * t) * 0.5 + 0.7);
  }, (i % 2 ? 0.5 : -0.5));
  reverbTap(o, 0.8, (t) => Math.sin(TAU * (80 - 40 * t) * t) * Math.exp(-t * 9) * 0.5 + noise() * Math.exp(-t * 80) * 0.3, (i - 2.5) * 0.25);
});

// ---------------------------------------------------------------- monitor interference + chirps
const GLITCH = [[24.0, 24.5], [31.6, 32.0], [36.6, 38.2], [48.0, 48.5], [53.6, 54.4]];
GLITCH.forEach(([a, b], k) => {
  const nl = lp(0.5);
  add(a, b - a, (t) => {
    const gate = Math.sin(TAU * (9 + k * 3) * t + Math.sin(t * 50)) > 0.1 ? 1 : 0.15;
    return (nl(noise()) * 0.5 + Math.sin(TAU * (700 + 900 * Math.sin(t * 30)) * t) * 0.08) * gate * 0.35 * (1 - smooth((t - (b - a) * 0.8) / ((b - a) * 0.2)));
  }, k % 2 ? 0.4 : -0.4);
});
add(24.0, 0.12, (t) => Math.sin(TAU * 1760 * t) * Math.exp(-t * 25) * 0.18, 0.2); // "feed online" beep

// ---------------------------------------------------------------- subtle electronic pulses (tempo rises)
for (let t = 14; t < 70.3;) {
  const u = clamp((t - 14) / 56);
  const lvl = 0.05 + 0.11 * u;
  add(t, 0.45, (tt) => (Math.sin(TAU * 110 * tt) * 0.8 + Math.sin(TAU * 220 * tt) * 0.2) * Math.exp(-tt * 9) * lvl, 0);
  t += 1.25 - 0.8 * u;
}

// ---------------------------------------------------------------- deep cinematic impacts
function hit(t0, level, dur = 2.6) {
  const nl = lp(0.05);
  add(t0, dur, (t) => {
    const sweep = Math.sin(TAU * (28 + 70 * Math.exp(-t * 6)) * t) * Math.exp(-t * 1.6);
    const rumble = nl(noise()) * 6 * Math.exp(-t * 2.2) * 0.4;
    const crack = noise() * Math.exp(-t * 60) * 0.5;
    return (sweep * 0.9 + rumble + crack) * level;
  });
}
[[12.0, 0.35], [25.0, 0.4], [31.8, 0.55], [33.0, 0.3], [38.9, 0.55], [46.2, 0.5], [54.0, 0.5], [58.0, 0.35], [76.6, 0.2]].forEach(([t, l]) => hit(t, l));
hit(74.4, 1.0, 4.5); // the blackout: a big deep impact out of total silence

// ---------------------------------------------------------------- final text: typing ticks (11 chars/s from 76.6 s)
for (let k = 0; k < 26; k++) {
  const t0 = 76.6 + k / 11;
  add(t0, 0.06, (t) => Math.sin(TAU * (1500 + (k % 3) * 220) * t) * Math.exp(-t * 90) * 0.1 + noise() * Math.exp(-t * 300) * 0.04, ((k % 5) - 2) * 0.2);
}
[80.0, 82.0].forEach((t) => add(t, 0.6, (tt) => Math.sin(TAU * 110 * tt) * Math.exp(-tt * 6) * 0.14));

// ---------------------------------------------------------------- global: remove anything leaking into the silence window, fades
const ramp = (a, b, x) => clamp((x - a) / (b - a));
for (let i = 0; i < N; i++) {
  const t = i / SR;
  let g = 1;
  g = t > SILENCE[0] && t < SILENCE[1] ? (t < SILENCE[0] + 0.03 ? 1 - ramp(SILENCE[0], SILENCE[0] + 0.03, t) : t > SILENCE[1] - 0.02 ? ramp(SILENCE[1] - 0.02, SILENCE[1], t) : 0) : 1;
  g *= smooth(t / 1.2) * (1 - smooth((t - 84) / 1.0));
  L[i] = Math.tanh(L[i] * 1.2 * g) * 0.85;
  R[i] = Math.tanh(R[i] * 1.2 * g) * 0.85;
}

function writeWav(file, l, r) {
  const n = l.length, buf = Buffer.alloc(44 + n * 4);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 4, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22); buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 4, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(n * 4, 40);
  for (let i = 0; i < n; i++) { buf.writeInt16LE(Math.round(clamp(l[i], -1, 1) * 32767), 44 + i * 4); buf.writeInt16LE(Math.round(clamp(r[i], -1, 1) * 32767), 46 + i * 4); }
  fs.writeFileSync(file, buf);
}
const outDir = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../public/audio");
fs.mkdirSync(outDir, { recursive: true });
writeWav(path.join(outDir, "fx.wav"), L, R);
console.log("wrote fx.wav");

// ---------------------------------------------------------------- narration (ffmpeg flite TTS)
function readWavMono(file) {
  const b = fs.readFileSync(file);
  let p = 12, data = null, ch = 1;
  while (p < b.length - 8) {
    const id = b.toString("ascii", p, p + 4), sz = b.readUInt32LE(p + 4);
    if (id === "fmt ") ch = b.readUInt16LE(p + 10);
    if (id === "data") { data = b.subarray(p + 8, p + 8 + Math.min(sz, b.length - p - 8)); break; }
    p += 8 + sz + (sz % 2);
  }
  const n = Math.floor(data.length / 2 / ch), out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = data.readInt16LE(i * 2 * ch) / 32768;
  return out;
}
const NL = new Float32Array(N), NR = new Float32Array(N);
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "narr-"));
let voiceOK = true;
CUES.forEach((cue, k) => {
  const txt = path.join(tmp, `c${k}.txt`), raw = path.join(tmp, `c${k}.wav`);
  fs.writeFileSync(txt, cue.text);
  const last = k === CUES.length - 1;
  const fx = `rubberband=pitch=${last ? 0.78 : 0.84},highpass=f=90,lowpass=f=5200,acompressor=threshold=0.1:ratio=3,aecho=0.8:0.6:${last ? "120|260" : "70|190"}:${last ? "0.45|0.3" : "0.3|0.18"},volume=${last ? 0.9 : 1.1}`;
  const r = spawnSync("ffmpeg", ["-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", `flite=textfile=${txt}:voice=rms`, "-af", fx, "-ar", String(SR), "-ac", "1", "-c:a", "pcm_s16le", raw]);
  if (r.status !== 0) { voiceOK = false; console.warn("narration line failed (ffmpeg flite/rubberband missing?):", cue.text, String(r.stderr)); return; }
  const v = readWavMono(raw);
  const end = cue.t + v.length / SR, nextT = CUES[k + 1] ? CUES[k + 1].t : 85;
  console.log(`cue ${k}: ${cue.t.toFixed(1)}s -> ${end.toFixed(1)}s ${end > nextT ? "  !! overlaps next cue" : ""}`);
  const s0 = Math.floor(cue.t * SR);
  for (let i = 0; i < v.length && s0 + i < N; i++) { NL[s0 + i] += v[i] * 0.95; NR[s0 + i] += v[i] * 0.95; }
});
let pk = 0;
for (let i = 0; i < N; i++) pk = Math.max(pk, Math.abs(NL[i]));
const ng = pk > 0 ? 0.8 / pk : 1; // normalise the voice-over to a healthy level
for (let i = 0; i < N; i++) { NL[i] *= ng; NR[i] *= ng; }
writeWav(path.join(outDir, "narration.wav"), NL, NR);
console.log(voiceOK ? "wrote narration.wav" : "narration.wav written with missing lines - install ffmpeg with flite+rubberband, or replace public/audio/narration.wav with your own voice-over (85 s, 44.1 kHz).");
