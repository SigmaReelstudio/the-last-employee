import React from "react";
import { Composition } from "remotion";
import { MainFilm } from "./compositions/MainFilm.jsx";
import { FPS, WIDTH, HEIGHT, DURATION_FRAMES } from "./timeline.js";

export const RemotionRoot = () => (
  <Composition id="TheLastEmployee" component={MainFilm} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
