import React from "react";
import { kf, SCENE_TIMES, pulse } from "../timeline.js";

// SCENE 3 - THE WARNING (25-40 s)
// Push-in to the monitor (feed shows him from behind + a silhouette). He turns: empty room.
// Rack focus down the empty aisle, monitor flickers, silhouette is now closer.
const [start, end] = SCENE_TIMES.mystery;

export const mystery = {
  id: "mystery",
  start,
  end,
  state(t, b) {
    let cam;
    if (t < 33.0) {
      cam = {
        pos: kf(t, [[25, [0.9, 1.5, -5.2]], [32.5, [0.42, 1.22, -7.5]]]),
        look: kf(t, [[25, [0, 1.25, -9.3]], [32.5, [0, 1.15, -9.3]]]),
        fov: kf(t, [[25, 34], [32.5, 28]]),
      };
    } else if (t < 35.8) {
      cam = { pos: kf(t, [[33, [-2.5, 1.5, -3.9]], [35.8, [-1.7, 1.55, -4.7]]]), look: [0, 1.5, -6.9], fov: 34 };
    } else if (t < 38.0) {
      cam = { pos: kf(t, [[35.8, [0.7, 1.58, -7.6]], [38, [0.55, 1.6, -7.3]]]), look: [0.1, 1.4, 6], fov: 40 };
    } else {
      cam = {
        pos: kf(t, [[38, [0.45, 1.2, -7.7]], [40, [0.3, 1.17, -8.1]]]),
        look: [0, 1.15, -9.3],
        fov: kf(t, [[38, 30], [40, 23]]),
      };
    }
    return {
      cam: { ...cam, roll: 0, shake: 0.5 },
      glitch: Math.max(pulse(t, 32.9, 33.15, 0.04) * 0.7, pulse(t, 35.75, 35.95, 0.04) * 0.6, pulse(t, 37.95, 38.2, 0.04) * 0.7, b.glitch),
      rack: t >= 35.9 && t < 38 ? { focus: kf(t, [[35.9, 0.9], [37.4, 10.5]]), range: 2.5 } : null,
    };
  },
  Overlay() { return null; },
};
