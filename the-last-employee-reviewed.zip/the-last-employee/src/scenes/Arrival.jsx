import React from "react";
import { kfl, kf, smooth, pulse, SCENE_TIMES } from "../timeline.js";

// SCENE 1 - THE ARRIVAL (0-12 s)
// Exterior of the skyscraper at night. Slow approach to the lit floor, then straight through the glass
// into the empty office while the lone employee steps in through the far door.
const [start, end] = SCENE_TIMES.arrival;

const POS = [[0, [17, 27, -72]], [4.5, [10, 15, -50]], [8.4, [2.6, 4.6, -27]], [10.2, [0.3, 2.0, -16]], [12, [0.25, 1.75, -10.6]]];
const LOOK = [[0, [0, 6, -14]], [4.5, [0, 3.6, -14]], [8.4, [0, 2.2, -8]], [10.2, [0.2, 1.7, 0]], [12, [0.4, 1.45, 6]]];

export const arrival = {
  id: "arrival",
  start,
  end,
  state(t, b) {
    return {
      cam: {
        pos: kfl(t, POS),
        look: kfl(t, LOOK),
        fov: kf(t, [[0, 34], [8, 36], [10.4, 52], [12, 44]]),
        roll: 0,
        shake: t > 9.6 ? 0.2 : 0.05,
      },
      glitch: pulse(t, 10.05, 10.35, 0.06) * 0.5,
      bloom: 1.25,
    };
  },
  Overlay({ t }) {
    const a = smooth((t - 1.2) / 1.2) * (1 - smooth((t - 6.2) / 1.2));
    const stamp = smooth((t - 7.2) / 0.6) * (1 - smooth((t - 11.2) / 0.5));
    return (
      <>
        <div style={{ position: "absolute", left: 0, right: 0, top: 300, textAlign: "center", opacity: a, fontFamily: "Helvetica, Arial, sans-serif", letterSpacing: 22, color: "#cffaff", fontSize: 54, fontWeight: 200, textShadow: "0 0 26px #19e3ff" }}>
          THE LAST<br />EMPLOYEE
        </div>
        <div style={{ position: "absolute", left: 70, bottom: 190, opacity: stamp, fontFamily: "'Courier New', monospace", color: "#7ff3ff", fontSize: 30, letterSpacing: 4, textShadow: "0 0 12px #19e3ff" }}>
          FLOOR 22 &nbsp;·&nbsp; 02:17 AM
        </div>
      </>
    );
  },
};
