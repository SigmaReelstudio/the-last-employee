import React from "react";
import { smooth, rnd, SCENE_TIMES } from "../timeline.js";

// SCENE 6 - FINAL MESSAGE (75-85 s): black screen, text, subtle electronic sound, end.
const [start, end] = SCENE_TIMES.finalMessage;
const TEXT = "YOUR SHIFT HAS JUST BEGUN.";

export const finalMessage = {
  id: "finalMessage",
  start,
  end,
  state() { return { blackout: 1, cam: { pos: [0, 1.7, 0], look: [0, 1.5, -5], fov: 40, roll: 0, shake: 0 } }; },
  Overlay({ t }) {
    const local = t - 76.6;
    const chars = Math.max(0, Math.min(TEXT.length, Math.floor(local * 11)));
    const fade = 1 - smooth((t - 83.6) / 1.2);
    const glitch = local > 0 && local < 3.5 && rnd(Math.floor(t * 30)) > 0.93;
    const shown = TEXT.slice(0, chars);
    const cursor = chars < TEXT.length || Math.floor(t * 2) % 2 === 0 ? "▌" : "";
    return (
      <div style={{ position: "absolute", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center", opacity: fade }}>
        <div style={{ width: 900, textAlign: "center", fontFamily: "'Courier New', monospace", fontWeight: 700, fontSize: 78, lineHeight: 1.25, letterSpacing: 6, color: "#bff9ff", textShadow: "0 0 18px #19e3ff, 0 0 48px #0aa6c4", transform: glitch ? "translateX(" + (rnd(t * 90) * 24 - 12) + "px)" : "none", filter: glitch ? "hue-rotate(40deg)" : "none" }}>
          {shown}<span style={{ opacity: 0.8 }}>{cursor}</span>
        </div>
      </div>
    );
  },
};
