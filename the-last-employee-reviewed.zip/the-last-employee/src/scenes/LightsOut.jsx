import React from "react";
import { kf, smooth, SCENE_TIMES, pulse } from "../timeline.js";

// SCENE 4 - THE OFFICE CHANGES (40-58 s)
// Lights die one by one, the hero ring ignites, fog thickens, monitors become surveillance feeds
// where the silhouette creeps closer; the monitor finally reads YOU WERE NEVER ALONE.
const [start, end] = SCENE_TIMES.lightsOut;
const EMP = [0, 0, -6.9];

export const lightsOut = {
  id: "lightsOut",
  start,
  end,
  state(t, b) {
    let cam;
    if (t < 47.4) {
      cam = {
        pos: kf(t, [[40, [3.9, 2.55, 7.2]], [47.4, [2.0, 2.05, 3.0]]]),
        look: kf(t, [[40, [0, 1.1, -6]], [47.4, [0, 1.0, -6]]]),
        fov: 38,
      };
    } else if (t < 52.5) {
      const th = kf(t, [[47.4, 0.55], [52.5, 1.85]]);
      const r = 3.1;
      cam = { pos: [EMP[0] + r * Math.sin(th), 1.45, EMP[2] + r * Math.cos(th)], look: [0, 1.25, -7.4], fov: 34 };
    } else if (t < 56.4) {
      cam = {
        pos: kf(t, [[52.5, [0.5, 1.25, -7.55]], [56.4, [0.4, 1.22, -7.9]]]),
        look: [0, 1.15, -9.3],
        fov: kf(t, [[52.5, 28], [56.4, 21]]),
      };
    } else {
      cam = {
        pos: kf(t, [[56.4, [1.6, 1.68, -8.3]], [58, [1.3, 1.68, -8.0]]]),
        look: [0, 1.62, -6.9],
        fov: kf(t, [[56.4, 26], [58, 20]]),
      };
    }
    return {
      cam: { ...cam, roll: kf(t, [[40, 0], [58, 0.012]]), shake: 0.6 },
      bloom: kf(t, [[40, 1.05], [48, 1.5], [58, 1.7]]),
      glitch: Math.max(b.glitch, pulse(t, 52.4, 52.6, 0.04) * 0.6, pulse(t, 56.3, 56.5, 0.04) * 0.5),
    };
  },
  Overlay({ t }) {
    const a = smooth((t - 41) / 1) * (1 - smooth((t - 57) / 0.8));
    return (
      <div style={{ position: "absolute", right: 70, top: 120, opacity: a * 0.8, fontFamily: "'Courier New', monospace", color: "#7ff3ff", fontSize: 28, letterSpacing: 3, textShadow: "0 0 10px #19e3ff" }}>
        ● REC
      </div>
    );
  },
};
