import React from "react";
import { kf, relCam, SCENE_TIMES, pulse } from "../timeline.js";

// SCENE 2 - SOMETHING IS WRONG (12-25 s)
// Slow tracking: over-the-shoulder, a low tracking move beside him over the reflective floor,
// then a rack focus from the employee to the hero monitor (23-25 s).
const [start, end] = SCENE_TIMES.reveal;

const OFF = [[12, [0.9, 1.65, 3.4]], [16.5, [0.7, 1.6, 2.8]], [18.6, [2.7, 0.5, 0.4]], [21.0, [2.4, 0.55, -0.1]], [23.2, [1.1, 1.55, 2.4]], [25, [0.9, 1.5, 1.7]]];
const LOOKOFF = [[12, [-0.1, 1.35, -2.2]], [18.6, [0, 0.95, -0.6]], [23.2, [0, 1.3, -3]], [25, [0, 1.25, -3.5]]];

export const reveal = {
  id: "reveal",
  start,
  end,
  state(t, b) {
    const c = relCam(b, kf(t, OFF), kf(t, LOOKOFF));
    return {
      cam: { ...c, fov: kf(t, [[12, 42], [18.6, 38], [25, 34]]), roll: 0, shake: 0.6 },
      glitch: Math.max(b.glitch, pulse(t, 12.0, 12.25, 0.04) * 0.7),
      rack: t > 23.0 ? { focus: kf(t, [[23.2, 1.9], [24.7, 5.4]]), range: 2.2 } : null,
    };
  },
  Overlay() { return null; },
};
