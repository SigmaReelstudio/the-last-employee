import React from "react";
import { kf, relCam, SCENE_TIMES, rnd } from "../timeline.js";

// SCENE 5 - THE REVEAL (58-75 s)
// He walks around the desk to the dark window. Over-the-shoulder, slow zoom. His mirrored image
// fades, a seated reflection remains at the desk and lifts its head. Hard cut to black at 74.4 s.
const [start, end] = SCENE_TIMES.finalReveal;

const OFF = [[58, [1.0, 1.65, 2.7]], [63, [0.7, 1.62, 1.7]], [75, [0.4, 1.6, 0.95]]];
const LOOKOFF = [[58, [0, 1.4, -3]], [63, [-0.1, 1.3, -6.5]], [75, [-0.05, 1.25, -7]]];
const lin = (x) => Math.min(1, Math.max(0, x));

export const finalReveal = {
  id: "finalReveal",
  start,
  end,
  state(t, b) {
    const c = relCam(b, kf(t, OFF), kf(t, LOOKOFF));
    const glitchy = t > 72.8 ? 0.35 + 0.5 * rnd(Math.floor(t * 30)) : 0;
    return {
      cam: { ...c, fov: kf(t, [[58, 40], [63, 36], [74.4, 22]], lin), roll: 0, shake: 0.35 },
      ghost: kf(t, [[64.2, 0], [67.0, 0.9]]),
      ghostLook: kf(t, [[67.5, 0], [72.6, 1]]),
      mirrorEmp: kf(t, [[58.2, 0], [59.6, 0.6], [64.2, 0.6], [65.8, 0]]),
      glitch: Math.max(b.glitch, glitchy * 0.8),
      rack: t > 63 ? { focus: kf(t, [[63, 2.2], [66, 9.2]]), range: 2.8 } : null,
      bloom: 1.8,
    };
  },
  Overlay() { return null; },
};
