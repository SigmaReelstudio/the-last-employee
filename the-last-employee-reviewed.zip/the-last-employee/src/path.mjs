// Shared by the video (timeline.js) and the audio generator (scripts/generate-audio.mjs).
// Employee walking path: [time(s), x, z]. Linear between waypoints, so speed is constant per leg.
export const WAYPOINTS = [
  [10.4, 0.0, 7.7],   // steps through the door
  [22.6, 0.0, -6.9],  // arrives at his desk
  [57.4, 0.0, -6.9],  // stands at desk (monitor, lights out)
  [58.8, 1.4, -7.7],  // walks around the desk toward the window
  [61.4, 1.4, -11.3],
  [62.8, 0.5, -12.5], // stops at the glass
];
export const STRIDE = 0.72; // metres per footstep

export function posAt(t) {
  const w = WAYPOINTS;
  if (t <= w[0][0]) return [w[0][1], w[0][2]];
  if (t >= w[w.length - 1][0]) return [w[w.length - 1][1], w[w.length - 1][2]];
  for (let i = 0; i < w.length - 1; i++) {
    if (t >= w[i][0] && t < w[i + 1][0]) {
      const u = (t - w[i][0]) / (w[i + 1][0] - w[i][0]);
      return [w[i][1] + (w[i + 1][1] - w[i][1]) * u, w[i][2] + (w[i + 1][2] - w[i][2]) * u];
    }
  }
}

// cumulative distance walked, sampled at 1/120 s
const STEP = 1 / 120;
const N = Math.ceil(90 / STEP);
const cum = new Float64Array(N + 1);
for (let i = 1; i <= N; i++) {
  const a = posAt((i - 1) * STEP), b = posAt(i * STEP);
  cum[i] = cum[i - 1] + Math.hypot(b[0] - a[0], b[1] - a[1]);
}
export function distAt(t) {
  const f = Math.min(N - 1, Math.max(0, t / STEP));
  const i = Math.floor(f);
  return cum[i] + (cum[i + 1] - cum[i]) * (f - i);
}
export function speedAt(t) {
  return (distAt(t + 0.05) - distAt(t - 0.05)) / 0.1;
}
// times of each footstep (used for audio sync)
export function footstepTimes() {
  const out = [];
  let k = 1;
  for (let i = 1; i <= N; i++) {
    while (cum[i] >= k * STRIDE) {
      out.push((i * STEP) * 1);
      k++;
    }
  }
  return out;
}
