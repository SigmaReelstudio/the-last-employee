import React, { useMemo } from "react";
import * as THREE from "three";
import Reflected from "./Reflected.jsx";
import { drawScreen } from "./feedCanvas.js";
import { rnd } from "../timeline.js";

// 12 workstations + the hero workstation. Every screen is a live canvas texture:
//   "ui"   generic scrolling terminal
//   "feed" surveillance-camera feed of the office (employee from behind + the silhouette behind him)
//   "text" the warning message
const XS = [-6.2, -3.4, 3.4, 6.2];
const ZS = [4.5, 0.4, -4.0];
export const DESKS = [];
ZS.forEach((z, r) => XS.forEach((x, c) => DESKS.push({ x, z, row: r, col: c })));
export const HERO = { x: 0, z: -9 };

function sourceFor(i, d, mode) {
  if (mode === "cams") {
    if (d.row === 2) return "cam" + [1, 2, 3, 1][d.col];
    if (d.row === 1 && (d.col === 1 || d.col === 2)) return "cam" + (d.col === 1 ? 2 : 3);
  }
  return "ui" + ((i % 3) + 1);
}

function useScreens() {
  return useMemo(() => {
    const mkc = () => { const c = document.createElement("canvas"); c.width = 512; c.height = 288; return c; };
    const mkt = (c) => { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; };
    const names = ["hero", "cam1", "cam2", "cam3", "ui1", "ui2", "ui3"];
    const canvas = {}, tex = {};
    names.forEach((n) => { canvas[n] = mkc(); tex[n] = mkt(canvas[n]); });
    return { canvas, tex };
  }, []);
}

function Desk({ x, z, map, glow, hero }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 0.75, 0]} castShadow receiveShadow><boxGeometry args={[1.6, 0.04, 0.8]} /><meshStandardMaterial color="#0d131a" roughness={0.25} metalness={0.7} /></mesh>
      {[-0.76, 0.76].map((dx) => (
        <mesh key={dx} position={[dx, 0.37, 0]} castShadow><boxGeometry args={[0.04, 0.74, 0.7]} /><meshStandardMaterial color="#0a0f15" roughness={0.5} metalness={0.5} /></mesh>
      ))}
      {/* keyboard + mug */}
      <mesh position={[0, 0.78, 0.18]}><boxGeometry args={[0.44, 0.015, 0.14]} /><meshStandardMaterial color="#06090d" roughness={0.4} metalness={0.6} /></mesh>
      <mesh position={[0.55, 0.82, 0.15]}><cylinderGeometry args={[0.04, 0.035, 0.09, 12]} /><meshStandardMaterial color="#d8dde2" roughness={0.4} /></mesh>
      {/* monitor */}
      <mesh position={[0, 0.82, -0.2]}><cylinderGeometry args={[0.05, 0.07, 0.08, 12]} /><meshStandardMaterial color="#10161d" metalness={0.8} roughness={0.3} /></mesh>
      <mesh position={[0, 1.12, -0.28]} castShadow><boxGeometry args={[0.64, 0.38, 0.03]} /><meshStandardMaterial color="#06090c" roughness={0.3} metalness={0.7} /></mesh>
      <Reflected>
        <mesh position={[0, 1.12, -0.262]}>
          <planeGeometry args={[0.59, 0.332]} />
          <meshBasicMaterial map={map} color={new THREE.Color("#ffffff").multiplyScalar(glow)} toneMapped={false} />
        </mesh>
      </Reflected>
      {/* chair (pulled out, facing the monitor) */}
      <group position={[0, 0, hero ? 1.1 : 0.95]} rotation={[0, hero ? 0.35 : (rnd(x * 7 + z) - 0.5) * 0.6, 0]}>
        <mesh position={[0, 0.48, 0]}><boxGeometry args={[0.46, 0.07, 0.46]} /><meshStandardMaterial color="#0b1016" roughness={0.6} /></mesh>
        <mesh position={[0, 0.8, 0.23]}><boxGeometry args={[0.44, 0.5, 0.05]} /><meshStandardMaterial color="#0b1016" roughness={0.6} /></mesh>
        <mesh position={[0, 0.24, 0]}><cylinderGeometry args={[0.035, 0.035, 0.44, 8]} /><meshStandardMaterial color="#222a33" metalness={0.8} roughness={0.3} /></mesh>
      </group>
    </group>
  );
}

export default function Monitors({ state }) {
  const S = useScreens();
  const { t, feed, entity, glitch, flicker } = state;

  drawScreen(S.canvas.hero, feed.hero, { t, angle: 0, entity, glitch, textStart: feed.textStart, seed: 0 });
  for (let i = 1; i <= 3; i++) {
    drawScreen(S.canvas["cam" + i], "feed", { t, angle: i, entity, glitch });
    drawScreen(S.canvas["ui" + i], "ui", { t, seed: i, glitch });
  }
  Object.values(S.tex).forEach((tx) => { tx.needsUpdate = true; });

  const frame = Math.floor(t * 30);
  const level = (i) => {
    const f = flicker > 0.01 && rnd(frame * 1.7 + i * 9.1) < 0.5 + flicker * 0.4 ? 1 - flicker * (0.55 + 0.4 * rnd(frame + i)) : 1;
    return 1.25 * f;
  };

  return (
    <group>
      {DESKS.map((d, i) => (
        <Desk key={i} x={d.x} z={d.z} map={S.tex[sourceFor(i, d, feed.others)]} glow={level(i)} />
      ))}
      <Desk x={HERO.x} z={HERO.z} map={S.tex.hero} glow={level(99) * 1.15} hero />
      {/* second, side monitor on the hero desk */}
      <group position={[-0.82, 0, -9.05]} rotation={[0, 0.5, 0]}>
        <mesh position={[0, 1.12, 0]}><boxGeometry args={[0.5, 0.31, 0.03]} /><meshStandardMaterial color="#06090c" roughness={0.3} metalness={0.7} /></mesh>
        <Reflected><mesh position={[0, 1.12, 0.017]}><planeGeometry args={[0.46, 0.27]} /><meshBasicMaterial map={S.tex.ui2} color={new THREE.Color("#fff").multiplyScalar(level(98))} toneMapped={false} /></mesh></Reflected>
      </group>
      {/* monitor light spilling on the employee */}
      <pointLight position={[0, 1.15, -8.4]} color="#37e8ff" intensity={2.2 * (feed.hero === "text" ? 1.6 : 1)} distance={5} decay={2} />
    </group>
  );
}
