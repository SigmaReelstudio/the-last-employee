import React from "react";
import * as THREE from "three";
import Cam from "./Camera.jsx";
import Lighting from "./Lighting.jsx";
import Office from "./Office.jsx";
import City from "./City.jsx";
import Monitors from "./Monitors.jsx";
import { FogLayers, Dust } from "./Fog.jsx";
import Employee from "./Employee.jsx";
import Effects from "./Effects.jsx";

// The complete 3D world. One continuous location: exterior tower -> office interior.
export default function World({ state }) {
  const { emp, t, cam, entity, entity3d, mirrorEmp, ghost, ghostLook = 0, fogExp } = state;
  const pose = { walkPhase: emp.walkPhase, walkAmp: emp.walkAmp, headYaw: emp.headYaw, headPitch: emp.headPitch, fear: emp.fear, blink: emp.blink, breath: emp.breath };
  const ex = emp.pos[0], ez = emp.pos[2];

  return (
    <>
      <color attach="background" args={["#02050a"]} />
      <fogExp2 attach="fog" args={["#06151c", fogExp]} />
      <Cam cam={cam} t={t} />
      <Lighting state={state} />
      <Office state={state} />
      <City />
      <Monitors state={state} />
      <FogLayers state={state} />
      <Dust state={state} />

      {/* the employee + his reflection in the glossy floor */}
      {emp.visible && (
        <>
          <Employee pose={pose} position={emp.pos} rotY={emp.rotY} />
          <group scale={[1, -1, 1]}>
            <Employee pose={pose} position={emp.pos} rotY={emp.rotY} castShadow={false} />
          </group>
        </>
      )}

      {/* the silhouette: only glimpsed in the real room while lights stutter */}
      {entity3d > 0.02 && <Employee mode="silhouette" opacity={entity3d} position={[ex, 0, ez + entity.dist]} rotY={Math.PI} castShadow={false} pose={{}} />}

      {/* window reflection of the standing employee (mirrored across the glass plane z = -14) */}
      {mirrorEmp > 0.01 && (
        <Employee mode="ghost" opacity={mirrorEmp} position={[ex, 0, -28 - ez]} rotY={Math.PI - emp.rotY} pose={pose} castShadow={false} />
      )}

      {/* the reflection that stays seated at the desk */}
      {ghost > 0.01 && (
        <group>
          <Employee mode="ghost" seated opacity={ghost} position={[0, 0, -19.95]} rotY={0} castShadow={false}
            pose={{ headPitch: 0.5 * (1 - ghostLook) - 0.04, headYaw: 0, fear: 0, breath: Math.sin(t * 1.6) }} />
          <mesh position={[0, 0.75, -19]}><boxGeometry args={[1.6, 0.04, 0.8]} /><meshBasicMaterial color="#58e8ff" transparent opacity={0.25 * ghost} blending={THREE.AdditiveBlending} depthWrite={false} /></mesh>
          <mesh position={[0, 1.12, -18.72]}><boxGeometry args={[0.64, 0.38, 0.03]} /><meshBasicMaterial color="#58e8ff" transparent opacity={0.3 * ghost} blending={THREE.AdditiveBlending} depthWrite={false} /></mesh>
        </group>
      )}

      <Effects state={state} />
    </>
  );
}
