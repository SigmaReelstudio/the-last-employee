import React, { useMemo, useLayoutEffect } from "react";
import * as THREE from "three";
import Reflected from "./Reflected.jsx";
import { FIXTURES } from "../timeline.js";
import { radialGlow } from "./textures.js";

// Ceiling fixtures (with point lights, volumetric light cones, glowing floor rings), cyan rim lights
// and a shadow-casting key light that follows the employee.
export default function Lighting({ state }) {
  const { lights, cyan, ringHero, t, emp, fog } = state;
  const glow = useMemo(() => radialGlow(), []);
  const avg = lights.slice(0, 6).reduce((a, b) => a + b, 0) / 6;

  const key = useMemo(() => {
    const l = new THREE.DirectionalLight("#bfeaff", 0.4);
    l.castShadow = true;
    l.shadow.mapSize.set(1024, 1024);
    const c = l.shadow.camera;
    c.left = -4; c.right = 4; c.top = 4; c.bottom = -4; c.near = 0.5; c.far = 14;
    l.shadow.bias = -0.0006;
    l.shadow.radius = 4;
    return l;
  }, []);
  useLayoutEffect(() => {
    const [x, , z] = emp.pos;
    key.position.set(x + 1.6, 3.4, z + 1.4);
    key.target.position.set(x, 0, z);
    key.target.updateMatrixWorld();
    key.intensity = 0.15 + 0.55 * avg + 0.25 * cyan * 0.5;
  });

  return (
    <>
      <ambientLight intensity={0.07} color="#4d7ba0" />
      <hemisphereLight args={["#27465f", "#05080c", 0.18]} />
      {/* cyan rim lighting from the window side and the door side */}
      <directionalLight position={[7, 2.5, -9]} intensity={0.55 * cyan} color="#19d9ff" />
      <directionalLight position={[-7, 2.8, 6]} intensity={0.32 * cyan} color="#18a8d6" />
      <primitive object={key} />
      <primitive object={key.target} />

      {FIXTURES.map(([x, z], i) => {
        const on = lights[i];
        const hero = i === 6;
        const ringI = hero ? 0.04 + ringHero * 2.4 : 0.14 + on * 0.95;
        const spin = t * (hero ? 0.9 : 0.15);
        return (
          <group key={i}>
            <pointLight position={[x, 3.25, z]} intensity={on * (hero ? 9 : 16)} color={hero ? "#37e8ff" : "#cdf6ff"} distance={13} decay={2} />
            {/* fixture disc, floor ring, soft glow */}
            <Reflected>
              <mesh position={[x, 3.58, z]} rotation={[Math.PI / 2, 0, 0]}>
                <circleGeometry args={[0.46, 32]} />
                <meshBasicMaterial color={new THREE.Color(hero ? "#37e8ff" : "#dffbff").multiplyScalar(0.12 + on * 3.2)} toneMapped={false} />
              </mesh>
              <group position={[x, 0.025, z]} rotation={[-Math.PI / 2, 0, 0]}>
                <mesh><ringGeometry args={[0.92, 1.04, 72]} /><meshBasicMaterial color={new THREE.Color("#19e3ff").multiplyScalar(ringI * 2.2)} toneMapped={false} /></mesh>
                <mesh position={[0, 0, -0.002]}><circleGeometry args={[1.9, 48]} /><meshBasicMaterial map={glow} color="#19c9ff" transparent opacity={Math.min(1, ringI * 0.45)} blending={THREE.AdditiveBlending} depthWrite={false} toneMapped={false} /></mesh>
                <group rotation={[0, 0, spin]}>
                  <mesh><ringGeometry args={[1.22, 1.27, 64, 1, 0, Math.PI * 1.35]} /><meshBasicMaterial color={new THREE.Color("#7ff6ff").multiplyScalar(ringI * (hero ? 2.8 : 0.9))} toneMapped={false} /></mesh>
                </group>
                {hero && ringHero > 0.01 ? (
                  <group rotation={[0, 0, -spin * 1.6]}>
                    <mesh><ringGeometry args={[1.5, 1.54, 64, 1, 0.6, Math.PI * 1.1]} /><meshBasicMaterial color={new THREE.Color("#a8fbff").multiplyScalar(ringHero * 3)} toneMapped={false} /></mesh>
                  </group>
                ) : null}
              </group>
            </Reflected>
            {/* volumetric light cone */}
            <mesh position={[x, 1.8, z]}>
              <coneGeometry args={[1.7, 3.5, 40, 1, true]} />
              <meshBasicMaterial color={hero ? "#37e8ff" : "#bdeeff"} transparent opacity={on * (0.025 + fog * 0.03)} blending={THREE.AdditiveBlending} depthWrite={false} side={THREE.DoubleSide} />
            </mesh>
          </group>
        );
      })}
    </>
  );
}
