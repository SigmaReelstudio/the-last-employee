import React, { useMemo } from "react";
import * as THREE from "three";
import { rnd } from "../timeline.js";
import { windowTexture, skyTexture, streetsTexture, withRepeat } from "./textures.js";

// Night skyline outside the tower + sky dome + street grid far below.
export default function City() {
  const { tex, sky, streets, buildings } = useMemo(() => {
    const tex = [windowTexture(2, 8, 16, 0.38), windowTexture(5, 8, 16, 0.22), windowTexture(9, 8, 16, 0.5), windowTexture(14, 8, 16, 0.3)];
    const list = [];
    for (let i = 0; i < 90; i++) {
      const z = -45 - rnd(i * 3.1) * 230;
      let x = (rnd(i * 5.7) - 0.5) * 320;
      if (z > -120 && Math.abs(x) < 22) x = x < 0 ? x - 26 : x + 26; // keep the flight corridor clear
      const w = 10 + rnd(i * 2.3) * 22, d = 10 + rnd(i * 4.1) * 22, h = 50 + rnd(i * 8.9) * 130 * (1 - (-z - 45) / 600);
      list.push({ x, z, w, d, h, ti: i % 4 });
    }
    return { tex, sky: skyTexture(), streets: withRepeat(streetsTexture(), 3, 3), buildings: list };
  }, []);

  return (
    <group>
      <mesh>
        <sphereGeometry args={[560, 24, 16]} />
        <meshBasicMaterial map={sky} side={THREE.BackSide} fog={false} depthWrite={false} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -83, -120]}>
        <planeGeometry args={[900, 900]} />
        <meshBasicMaterial map={streets} color="#ffffff" />
      </mesh>
      {buildings.map((b, i) => (
        <Building key={i} b={b} tex={tex[b.ti]} />
      ))}
    </group>
  );
}

function Building({ b, tex }) {
  const { geo, mat } = useMemo(() => {
    const geo = new THREE.BoxGeometry(b.w, b.h, b.d);
    const uv = geo.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * (b.w / 20), uv.getY(i) * (b.h / 40));
    const mat = new THREE.MeshStandardMaterial({ color: "#04080d", roughness: 0.5, metalness: 0.4, emissive: "#ffffff", emissiveMap: tex, emissiveIntensity: 1.0 });
    return { geo, mat };
  }, [b, tex]);
  return <mesh geometry={geo} material={mat} position={[b.x, -83 + b.h / 2, b.z]} />;
}
