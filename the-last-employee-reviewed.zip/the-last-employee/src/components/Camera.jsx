import React, { useLayoutEffect } from "react";
import { useThree } from "@react-three/fiber";

// Applies the scene's camera (position, look-at, FOV, roll) + a restrained deterministic handheld drift.
export default function Cam({ cam, t }) {
  const { camera } = useThree();
  useLayoutEffect(() => {
    const s = cam.shake ?? 0.4;
    const n = (f, p) => Math.sin(t * f + p) * 0.6 + Math.sin(t * f * 2.31 + p * 1.7) * 0.4;
    camera.position.set(cam.pos[0] + n(0.9, 1) * 0.012 * s, cam.pos[1] + n(1.1, 2) * 0.01 * s, cam.pos[2] + n(0.7, 3) * 0.012 * s);
    camera.up.set(Math.sin(cam.roll || 0), Math.cos(cam.roll || 0), 0);
    camera.lookAt(cam.look[0] + n(0.6, 4) * 0.01 * s, cam.look[1] + n(0.8, 5) * 0.008 * s, cam.look[2]);
    camera.fov = cam.fov;
    camera.near = 0.05;
    camera.far = 800;
    camera.updateProjectionMatrix();
  });
  return null;
}
