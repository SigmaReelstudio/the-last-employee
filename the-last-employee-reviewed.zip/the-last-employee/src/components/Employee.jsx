import React, { useMemo } from "react";
import * as THREE from "three";

const Cap = ({ r, l, p = [0, 0, 0], m, cs }) => (
  <mesh position={p} castShadow={cs} material={m}>
    <capsuleGeometry args={[r, l, 4, 10]} />
  </mesh>
);

// Stylised realistic human built from primitives (capsules/spheres/boxes) with a procedural rig.
// Forward axis = +Z in local space. rotY = 0 faces +Z, rotY = PI faces -Z.
// mode: "normal" (the employee) | "silhouette" (the other one) | "ghost" (cyan reflection)
export default function Employee({ pose = {}, mode = "normal", opacity = 1, position = [0, 0, 0], rotY = 0, seated = false, castShadow = true }) {
  const { walkPhase = 0, walkAmp = 0, headYaw = 0, headPitch = 0, fear = 0, blink = 0, breath = 0 } = pose;

  const M = useMemo(() => {
    if (mode === "ghost") {
      const g = () => new THREE.MeshBasicMaterial({ color: "#6df3ff", transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false });
      const a = g();
      return { jacket: a, shirt: g(), pants: a, skin: g(), hair: a, shoe: a, eye: g(), pupil: a, tie: a };
    }
    if (mode === "silhouette") {
      const k = new THREE.MeshStandardMaterial({ color: "#000", roughness: 1, metalness: 0, emissive: "#02222b", emissiveIntensity: 0.6, transparent: true });
      return { jacket: k, shirt: k, pants: k, skin: k, hair: k, shoe: k, eye: k, pupil: k, tie: k };
    }
    const std = (color, r = 0.7, m = 0) => new THREE.MeshStandardMaterial({ color, roughness: r, metalness: m });
    return {
      jacket: std("#1d2635", 0.75), shirt: std("#d7dde4", 0.6), pants: std("#10131a", 0.8),
      skin: std("#b98a6e", 0.55), hair: std("#0b0b0e", 0.5), shoe: std("#050506", 0.25, 0.3),
      eye: std("#f4f4f4", 0.3), pupil: std("#080808", 0.2), tie: std("#0f6f86", 0.5),
    };
  }, [mode]);
  if (mode === "ghost") { M.jacket.opacity = 0.3 * opacity; M.skin.opacity = 0.38 * opacity; M.shirt.opacity = 0.34 * opacity; M.eye.opacity = 0.7 * opacity; }
  if (mode === "silhouette") M.jacket.opacity = opacity;

  const cs = castShadow && mode !== "ghost";
  const amp = seated ? 0 : walkAmp;
  const sw = Math.sin(walkPhase);
  const bob = Math.abs(Math.sin(walkPhase)) * 0.025 * amp;

  const hipY = seated ? 0.53 : 0.93 + bob;
  const legL = seated ? -1.52 : sw * 0.55 * amp;
  const legR = seated ? -1.52 : -sw * 0.55 * amp;
  const kneeL = seated ? 1.5 : Math.max(0, -Math.cos(walkPhase)) * 0.75 * amp;
  const kneeR = seated ? 1.5 : Math.max(0, Math.cos(walkPhase)) * 0.75 * amp;
  const armL = seated ? -1.05 : -sw * 0.45 * amp;
  const armR = seated ? -1.05 : sw * 0.45 * amp;
  const elbow = seated ? -0.75 : -0.15 - 0.25 * amp;

  return (
    <group position={position} rotation={[0, rotY, 0]}>
      <group position={[0, hipY, seated ? -0.12 : 0]} rotation={[0, sw * 0.06 * amp, 0]}>
        {/* pelvis + torso */}
        <mesh castShadow={cs} material={M.pants} position={[0, 0.02, 0]}><boxGeometry args={[0.34, 0.2, 0.2]} /></mesh>
        <group position={[0, 0.0, 0]} rotation={[seated ? 0.08 : 0, 0, 0]} scale={[1 + breath * 0.008, 1 + breath * 0.012, 1]}>
          <mesh castShadow={cs} material={M.jacket} position={[0, 0.38, 0]}><boxGeometry args={[0.44, 0.56, 0.25]} /></mesh>
          <mesh castShadow={cs} material={M.jacket} position={[0, 0.63, 0]}><boxGeometry args={[0.5, 0.1, 0.26]} /></mesh>
          <mesh material={M.shirt} position={[0, 0.42, 0.127]}><boxGeometry args={[0.1, 0.4, 0.01]} /></mesh>
          <mesh material={M.tie} position={[0, 0.38, 0.135]}><boxGeometry args={[0.04, 0.3, 0.01]} /></mesh>
          <mesh castShadow={cs} material={M.skin} position={[0, 0.72, 0]}><cylinderGeometry args={[0.05, 0.055, 0.1, 10]} /></mesh>

          {/* head */}
          <group position={[0, 0.84, 0.01]} rotation={[headPitch, headYaw, 0]}>
            <mesh castShadow={cs} material={M.skin} scale={[1, 1.12, 1.02]}><sphereGeometry args={[0.112, 20, 16]} /></mesh>
            <mesh castShadow={cs} material={M.hair} position={[0, 0.025, -0.012]} scale={[1.04, 1.1, 1.06]}><sphereGeometry args={[0.114, 20, 12, 0, Math.PI * 2, 0, 1.75]} /></mesh>
            {[-1, 1].map((s) => (
              <group key={s} position={[s * 0.043, 0.015, 0.098]}>
                <mesh material={M.eye} scale={[1, 1 - blink * 0.85, 1]}><sphereGeometry args={[0.017 + fear * 0.004, 10, 8]} /></mesh>
                <mesh material={M.pupil} position={[0, 0, 0.014]} scale={[1, 1 - blink * 0.85, 1]}><sphereGeometry args={[0.007, 8, 6]} /></mesh>
                <mesh material={M.hair} position={[0, 0.03 + fear * 0.008, 0.004]} rotation={[0, 0, s * (0.08 - fear * 0.35)]}><boxGeometry args={[0.04, 0.007, 0.006]} /></mesh>
              </group>
            ))}
            <mesh material={M.skin} position={[0, -0.01, 0.112]} rotation={[0.3, 0, 0]}><coneGeometry args={[0.014, 0.04, 6]} /></mesh>
            <mesh material={M.hair} position={[0, -0.062, 0.1]} scale={[1, 1 + fear * 1.6, 1]}><boxGeometry args={[0.036, 0.006, 0.006]} /></mesh>
          </group>

          {/* arms */}
          {[[-1, armL], [1, armR]].map(([s, a]) => (
            <group key={s} position={[s * 0.285, 0.6, 0]} rotation={[a, 0, s * 0.05]}>
              <Cap cs={cs} r={0.05} l={0.22} p={[0, -0.15, 0]} m={M.jacket} />
              <group position={[0, -0.3, 0]} rotation={[elbow, 0, 0]}>
                <Cap cs={cs} r={0.042} l={0.21} p={[0, -0.14, 0]} m={M.jacket} />
                <mesh castShadow={cs} material={M.skin} position={[0, -0.31, 0]}><sphereGeometry args={[0.045, 10, 8]} /></mesh>
              </group>
            </group>
          ))}
        </group>

        {/* legs */}
        {[[-1, legL, kneeL], [1, legR, kneeR]].map(([s, a, k]) => (
          <group key={s} position={[s * 0.1, -0.05, 0]} rotation={[a, 0, 0]}>
            <Cap cs={cs} r={0.07} l={0.34} p={[0, -0.23, 0]} m={M.pants} />
            <group position={[0, -0.46, 0]} rotation={[k, 0, 0]}>
              <Cap cs={cs} r={0.055} l={0.34} p={[0, -0.22, 0]} m={M.pants} />
              <mesh castShadow={cs} material={M.shoe} position={[0, -0.46, 0.06]}><boxGeometry args={[0.095, 0.06, 0.26]} /></mesh>
            </group>
          </group>
        ))}
      </group>
    </group>
  );
}
