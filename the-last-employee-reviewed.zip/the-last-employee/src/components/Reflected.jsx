import React from "react";

/** Renders children twice: once normally and once mirrored under the floor (y -> -y).
 *  The glossy floor is semi-transparent, so the mirrored copy reads as a reflection.
 *  (Closest working alternative to a planar-reflection shader, which needs @react-three/drei.) */
export default function Reflected({ children }) {
  return (
    <>
      <group>{children}</group>
      <group scale={[1, -1, 1]}>{children}</group>
    </>
  );
}
