import React, { useMemo } from "react";
import * as THREE from "three";
import { fogTexture } from "./textures.js";
import { rnd } from "../timeline.js";

// Layered volumetric fog: stacked drifting noise slabs + scene-level exponential fog (set in World).
const LAYERS = [
  { y: 0.1, add: false, o: 0.5, speed: 0.006, color: "#0b2f3b" },
  { y: 0.4, add: true, o: 0.1, speed: -0.004, color: "#2a8aa0" },
  { y: 0.8, add: false, o: 0.38, speed: 0.005, color: "#0b2f3b" },
  { y: 1.3, add: true, o: 0.08, speed: -0.006, color: "#2a8aa0" },
  { y: 1.9, add: false, o: 0.26, speed: 0.003, color: "#0a2630" },
  { y: 2.6, add: true, o: 0.05, speed: 0.004, color: "#2a8aa0" },
];

export function FogLayers({ state }) {
  const tex = useMemo(() => LAYERS.map((_, i) => { const t = fogTexture(i * 17 + 3); t.repeat.set(2.2, 2.6); return t; }), []);
  const { t, fog } = state;
  return (
    <group>
      {LAYERS.map((L, i) => {
        tex[i].offset.set(t * L.speed * 2.0, t * L.speed);
        return (
          <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={[0, L.y, -3]}>
            <planeGeometry args={[18, 22]} />
            <meshBasicMaterial map={tex[i]} color={L.color} transparent opacity={Math.min(0.85, L.o * fog)} blending={L.add ? THREE.AdditiveBlending : THREE.NormalBlending} depthWrite={false} side={THREE.DoubleSide} />
          </mesh>
        );
      })}
    </group>
  );
}

const N = 650;
export function Dust({ state }) {
  const { geo, base } = useMemo(() => {
    const base = new Float32Array(N * 4);
    for (let i = 0; i < N; i++) {
      base[i * 4] = (rnd(i * 1.3) - 0.5) * 17;
      base[i * 4 + 1] = 0.2 + rnd(i * 2.9) * 3.2;
      base[i * 4 + 2] = -13 + rnd(i * 4.7) * 20;
      base[i * 4 + 3] = rnd(i * 6.1) * 6.28;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(N * 3), 3));
    return { geo, base };
  }, []);
  const t = state.t;
  const pos = geo.attributes.position.array;
  for (let i = 0; i < N; i++) {
    const ph = base[i * 4 + 3];
    pos[i * 3] = base[i * 4] + Math.sin(t * 0.21 + ph) * 0.35;
    pos[i * 3 + 1] = base[i * 4 + 1] + Math.sin(t * 0.33 + ph * 1.7) * 0.18 - ((t * 0.02 * (1 + rnd(i))) % 0.5);
    pos[i * 3 + 2] = base[i * 4 + 2] + Math.cos(t * 0.17 + ph) * 0.35;
  }
  geo.attributes.position.needsUpdate = true;
  geo.computeBoundingSphere();
  return (
    <points geometry={geo} frustumCulled={false}>
      <pointsMaterial color="#c4f7ff" size={0.014} sizeAttenuation transparent opacity={0.75} blending={THREE.AdditiveBlending} depthWrite={false} />
    </points>
  );
}
