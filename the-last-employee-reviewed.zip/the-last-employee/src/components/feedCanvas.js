// 2D-canvas drawing for every monitor in the office (generic UI, surveillance "live feed", warning text).
// Pure functions of (kind, params) -> deterministic frame-based output.
import { rnd } from "../timeline.js";

const CYAN = "#37e8ff";

export function drawScreen(canvas, kind, p) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
  ctx.fillStyle = "#020a0f";
  ctx.fillRect(0, 0, w, h);
  if (kind === "ui") ui(ctx, w, h, p);
  else if (kind === "feed") feed(ctx, w, h, p);
  else if (kind === "text") text(ctx, w, h, p);
  // scanlines
  ctx.fillStyle = "rgba(0,0,0,0.22)";
  for (let y = 0; y < h; y += 3) ctx.fillRect(0, y, w, 1);
  glitchSlices(ctx, w, h, p);
}

function ui(ctx, w, h, p) {
  const { t, seed = 1 } = p;
  ctx.fillStyle = "rgba(55,232,255,0.16)";
  ctx.fillRect(0, 0, w, 26);
  ctx.fillStyle = CYAN;
  ctx.font = "bold 16px monospace";
  ctx.fillText("NIGHT-SHIFT // TERMINAL " + (10 + seed), 10, 18);
  const rowH = 16;
  const scroll = (t * 18) % rowH;
  const base = Math.floor(t * 18 / rowH);
  for (let i = 0; i < 17; i++) {
    const r = base + i;
    const y = 34 + i * rowH - scroll;
    const indent = Math.floor(rnd(r * 3 + seed) * 4) * 22;
    const len = 40 + rnd(r * 7 + seed * 5) * (w * 0.55);
    ctx.fillStyle = rnd(r * 11 + seed) > 0.8 ? "rgba(255,255,255,0.75)" : "rgba(55,232,255,0.65)";
    ctx.fillRect(14 + indent, y, len, 6);
    if (rnd(r + seed * 9) > 0.6) { ctx.fillStyle = "rgba(55,232,255,0.4)"; ctx.fillRect(18 + indent + len + 6, y, 50, 6); }
  }
  // little chart
  ctx.strokeStyle = CYAN; ctx.lineWidth = 2; ctx.beginPath();
  for (let x = 0; x < 150; x += 3) {
    const y = h - 40 - 22 * Math.sin(x * 0.08 + t * 2 + seed) * Math.sin(x * 0.03 + seed);
    if (x === 0) ctx.moveTo(w - 170 + x, y); else ctx.lineTo(w - 170 + x, y);
  }
  ctx.stroke();
}

function text(ctx, w, h, p) {
  const { t, textStart = 54 } = p;
  const msg = ["YOU WERE", "NEVER ALONE."];
  const total = msg[0].length + msg[1].length;
  const n = Math.max(0, Math.min(total, Math.floor((t - textStart) * 12)));
  ctx.textAlign = "center";
  ctx.font = "bold 64px monospace";
  ctx.shadowColor = CYAN; ctx.shadowBlur = 24; ctx.fillStyle = "#c8fbff";
  const l1 = msg[0].slice(0, Math.min(n, msg[0].length));
  const l2 = msg[1].slice(0, Math.max(0, n - msg[0].length));
  ctx.fillText(l1, w / 2, h * 0.42);
  ctx.fillText(l2 + (Math.floor(t * 3) % 2 === 0 ? "_" : ""), w / 2, h * 0.42 + 78);
  ctx.textAlign = "start";
}

function person(ctx, x, feet, s, fill, edge, head = 1) {
  ctx.save();
  ctx.fillStyle = fill;
  ctx.strokeStyle = edge || "transparent";
  ctx.lineWidth = 2;
  if (edge) { ctx.shadowColor = edge; ctx.shadowBlur = 10; }
  const r = (v) => v * s;
  // legs
  ctx.fillRect(x - r(0.1), feet - r(0.5), r(0.08), r(0.5));
  ctx.fillRect(x + r(0.02), feet - r(0.5), r(0.08), r(0.5));
  // torso
  ctx.beginPath();
  ctx.moveTo(x - r(0.14), feet - r(0.5));
  ctx.lineTo(x - r(0.17), feet - r(0.82));
  ctx.quadraticCurveTo(x, feet - r(0.88), x + r(0.17), feet - r(0.82));
  ctx.lineTo(x + r(0.14), feet - r(0.5));
  ctx.closePath();
  ctx.fill();
  if (edge) ctx.stroke();
  // arms
  ctx.fillRect(x - r(0.22), feet - r(0.8), r(0.05), r(0.3));
  ctx.fillRect(x + r(0.17), feet - r(0.8), r(0.05), r(0.3));
  // head
  ctx.beginPath();
  ctx.ellipse(x, feet - r(0.93), r(0.065), r(0.075) * head, 0, 0, Math.PI * 2);
  ctx.fill();
  if (edge) ctx.stroke();
  ctx.restore();
}

function feed(ctx, w, h, p) {
  const { t, angle = 0, entity = { alpha: 0, dist: 3 }, emp } = p;
  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, "#041a22"); bg.addColorStop(1, "#02090d");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = "rgba(55,232,255,0.22)"; ctx.lineWidth = 1;
  const a = entity.alpha;
  const flick = 0.85 + 0.15 * rnd(Math.floor(t * 30) + angle);
  const d = entity.dist * (1 - 0.14 * angle); // each camera shows it a little closer

  if (angle === 0) {
    // high camera behind him, looking down the aisle at his desk
    const vx = w / 2, vy = h * 0.28;
    for (let i = -8; i <= 8; i++) { ctx.beginPath(); ctx.moveTo(vx, vy); ctx.lineTo(vx + i * w * 0.18, h); ctx.stroke(); }
    for (let k = 1; k < 9; k++) { const y = vy + (h - vy) * Math.pow(k / 9, 1.8); ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
    ctx.fillStyle = "rgba(55,232,255,0.10)";
    ctx.fillRect(w * 0.03, h * 0.38, w * 0.2, h * 0.2); ctx.fillRect(w * 0.77, h * 0.38, w * 0.2, h * 0.2);
    ctx.fillRect(w * 0.34, h * 0.3, w * 0.32, h * 0.1);
    const s = h * 0.62;
    person(ctx, w / 2, h * 0.86, s, "#5a7f88", null);
    if (a > 0.01) {
      const se = s * (9 / Math.max(2.2, 9 - d));
      ctx.globalAlpha = a * flick;
      person(ctx, w / 2 + Math.sin(t * 0.7) * 5, Math.min(h * 1.1, h * 0.86 + (se - s) * 0.45), se, "#000", CYAN, 1.15);
      ctx.globalAlpha = 1;
    }
  } else if (angle === 1) {
    // side camera
    ctx.beginPath(); ctx.moveTo(0, h * 0.82); ctx.lineTo(w, h * 0.82); ctx.stroke();
    ctx.fillStyle = "rgba(55,232,255,0.1)"; ctx.fillRect(w * 0.05, h * 0.55, w * 0.18, h * 0.27);
    person(ctx, w * 0.36, h * 0.82, h * 0.55, "#5a7f88");
    if (a > 0.01) { ctx.globalAlpha = a * flick; person(ctx, w * 0.36 + d * w * 0.1, h * 0.82, h * 0.58, "#000", CYAN, 1.15); ctx.globalAlpha = 1; }
  } else if (angle === 2) {
    // top-down camera
    for (let i = 1; i < 10; i++) { ctx.beginPath(); ctx.moveTo(i * w / 10, 0); ctx.lineTo(i * w / 10, h); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, i * h / 10); ctx.lineTo(w, i * h / 10); ctx.stroke(); }
    ctx.fillStyle = "#5a7f88"; ctx.beginPath(); ctx.ellipse(w / 2, h * 0.4, w * 0.07, h * 0.06, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(w / 2, h * 0.4, h * 0.035, 0, 7); ctx.fillStyle = "#8fb4bd"; ctx.fill();
    if (a > 0.01) {
      ctx.globalAlpha = a * flick; ctx.shadowColor = CYAN; ctx.shadowBlur = 14; ctx.fillStyle = "#000";
      ctx.beginPath(); ctx.ellipse(w / 2, h * 0.4 + d * h * 0.085, w * 0.08, h * 0.07, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(w / 2, h * 0.4 + d * h * 0.085, h * 0.04, 0, 7); ctx.fill(); ctx.globalAlpha = 1; ctx.shadowBlur = 0;
    }
  } else {
    // wide corner camera
    const vx = w * 0.15, vy = h * 0.2;
    for (let i = 0; i < 10; i++) { ctx.beginPath(); ctx.moveTo(vx, vy); ctx.lineTo(w * (i / 8), h); ctx.stroke(); }
    ctx.fillStyle = "rgba(55,232,255,0.1)"; ctx.fillRect(w * 0.5, h * 0.55, w * 0.4, h * 0.12);
    person(ctx, w * 0.62, h * 0.8, h * 0.3, "#5a7f88");
    if (a > 0.01) { ctx.globalAlpha = a * flick; person(ctx, w * 0.62 - d * w * 0.045, h * 0.84, h * 0.34, "#000", CYAN, 1.15); ctx.globalAlpha = 1; }
  }
  // HUD
  ctx.shadowBlur = 0;
  ctx.fillStyle = CYAN; ctx.font = "bold 18px monospace";
  ctx.fillText("CAM 0" + (angle + 1), 12, 24);
  ctx.fillStyle = Math.floor(t * 2) % 2 ? "#ff3b3b" : "#661515"; ctx.beginPath(); ctx.arc(w - 60, 19, 6, 0, 7); ctx.fill();
  ctx.fillStyle = CYAN; ctx.fillText("REC", w - 46, 25);
  const sec = Math.max(0, Math.floor(t - 10.4));
  const mm = 17 + Math.floor(sec / 60), ss = sec % 60;
  ctx.fillText("02:" + String(mm).padStart(2, "0") + ":" + String(ss).padStart(2, "0"), 12, h - 12);
  // noise
  for (let i = 0; i < 90; i++) { ctx.fillStyle = "rgba(180,255,255," + (rnd(i + t * 60) * 0.12) + ")"; ctx.fillRect(rnd(i * 3 + t * 91) * w, rnd(i * 5 + t * 37) * h, 2, 1); }
}

function glitchSlices(ctx, w, h, p) {
  const g = p.glitch || 0;
  if (g < 0.05) return;
  const n = Math.floor(2 + g * 6);
  for (let i = 0; i < n; i++) {
    const y = Math.floor(rnd(i + Math.floor(p.t * 30) * 7) * h);
    const hh = 4 + Math.floor(rnd(i * 3 + p.t) * 24);
    const dx = (rnd(i * 5 + Math.floor(p.t * 30)) - 0.5) * 80 * g;
    ctx.drawImage(ctx.canvas, 0, y, w, hh, dx, y, w, hh);
  }
}
