import React, { useMemo } from "react";
import * as THREE from "three";
import Reflected from "./Reflected.jsx";
import { windowTexture, withRepeat } from "./textures.js";

// The office shell: glossy floor, ceiling, walls, glass curtain wall, door, cyan strip lights, and the
// skyscraper facade seen from outside. Interior floor-plan: x in [-9, 9], z in [-14 (window), 8 (door)], y in [0, 3.6].
const H = 3.6;

export default function Office({ state }) {
  const cyan = state.cyan;
  const facade = useMemo(() => {
    const base = windowTexture(21, 8, 16, 0.2);
    return {
      front: withRepeat(base, 1, 79.4 / 57.6),
      frontLow: withRepeat(base, 1, 83 / 57.6),
      side: withRepeat(base, 22.65 / 19.2, 160 / 57.6),
    };
  }, []);
  const facadeMat = (map) => <meshStandardMaterial color="#05090e" roughness={0.35} metalness={0.7} emissive="#ffffff" emissiveMap={map} emissiveIntensity={0.9} />;
  const dark = <meshStandardMaterial color="#0a1017" roughness={0.55} metalness={0.5} />;
  const mullions = [-7.5, -4.5, -1.5, 1.5, 4.5, 7.5];

  return (
    <group>
      {/* ---- glossy reflective floor (semi-transparent so the mirrored copy beneath shows through) */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, -3]} receiveShadow>
        <planeGeometry args={[18, 22]} />
        <meshStandardMaterial color="#05090d" roughness={0.1} metalness={0.85} transparent opacity={0.74} />
      </mesh>
      {/* ---- ceiling + beams */}
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, H, -3]}>
        <planeGeometry args={[18, 22]} />
        <meshStandardMaterial color="#070b10" roughness={0.9} />
      </mesh>
      {[-12, -9, -6, -3, 0, 3, 6].map((z) => (
        <mesh key={z} position={[0, H - 0.1, z]}><boxGeometry args={[18, 0.2, 0.25]} />{dark}</mesh>
      ))}
      {/* ---- side walls (inward facing) */}
      <mesh rotation={[0, Math.PI / 2, 0]} position={[-9, H / 2, -3]} receiveShadow><planeGeometry args={[22, H]} />{dark}</mesh>
      <mesh rotation={[0, -Math.PI / 2, 0]} position={[9, H / 2, -3]} receiveShadow><planeGeometry args={[22, H]} />{dark}</mesh>
      {/* ---- door wall (z = 8) with opening at x in [-1, 1] */}
      <mesh position={[-5.0, H / 2, 8]}><boxGeometry args={[8, H, 0.3]} />{dark}</mesh>
      <mesh position={[5.0, H / 2, 8]}><boxGeometry args={[8, H, 0.3]} />{dark}</mesh>
      <mesh position={[0, 3.05, 8]}><boxGeometry args={[2, 1.1, 0.3]} />{dark}</mesh>
      <mesh position={[0, 1.25, 8.35]}>
        <planeGeometry args={[2, 2.5]} />
        <meshBasicMaterial color="#8fc9d6" />
      </mesh>
      <mesh position={[0, 1.25, 8.0]}><planeGeometry args={[2.0, 2.5]} /><meshBasicMaterial color="#bfeaf2" transparent opacity={0.0} /></mesh>
      {/* ---- window wall: glass + mullions */}
      <mesh position={[0, H / 2, -14]}>
        <planeGeometry args={[18, H]} />
        <meshPhysicalMaterial color="#a8f3ff" transparent opacity={0.05} roughness={0.04} metalness={0} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      {mullions.map((x) => (
        <mesh key={x} position={[x, H / 2, -14]}><boxGeometry args={[0.07, H, 0.12]} />{dark}</mesh>
      ))}
      <mesh position={[0, 0.06, -14]}><boxGeometry args={[18, 0.12, 0.2]} />{dark}</mesh>
      <mesh position={[0, H - 0.06, -14]}><boxGeometry args={[18, 0.12, 0.2]} />{dark}</mesh>

      {/* ---- cyan strip lights (reflected in the floor) */}
      <Reflected>
        {[-8.92, 8.92].map((x) => (
          <mesh key={x} position={[x, 0.1, -3]}><boxGeometry args={[0.05, 0.05, 21.5]} /><meshBasicMaterial color={new THREE.Color("#19d9ff").multiplyScalar(0.8 + cyan * 0.9)} toneMapped={false} /></mesh>
        ))}
        <mesh position={[0, 0.1, 7.85]}><boxGeometry args={[18, 0.05, 0.05]} /><meshBasicMaterial color={new THREE.Color("#19d9ff").multiplyScalar(0.7 + cyan * 0.6)} toneMapped={false} /></mesh>
      </Reflected>
      {[-8.92, 8.92].map((x) => (
        <mesh key={"c" + x} position={[x, H - 0.12, -3]}><boxGeometry args={[0.05, 0.04, 21.5]} /><meshBasicMaterial color={new THREE.Color("#19d9ff").multiplyScalar(0.8 + cyan * 0.8)} toneMapped={false} /></mesh>
      ))}

      {/* ---- tower facade seen from outside (windowed planes above and below the lit office floor) */}
      <mesh position={[0, H + 79.4 / 2, -14.06]} rotation={[0, Math.PI, 0]}><planeGeometry args={[19.2, 79.4]} />{facadeMat(facade.front)}</mesh>
      <mesh position={[0, -83 / 2, -14.06]} rotation={[0, Math.PI, 0]}><planeGeometry args={[19.2, 83]} />{facadeMat(facade.frontLow)}</mesh>
      <mesh position={[9.6, 0, -3]} rotation={[0, Math.PI / 2, 0]}><planeGeometry args={[22.65, 166]} />{facadeMat(facade.side)}</mesh>
      <mesh position={[-9.6, 0, -3]} rotation={[0, -Math.PI / 2, 0]}><planeGeometry args={[22.65, 166]} />{facadeMat(facade.side)}</mesh>
      <mesh position={[0, 83, -3]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[19.2, 22.65]} /><meshStandardMaterial color="#05090d" /></mesh>
    </group>
  );
}
