import * as THREE from "three";
import { rnd } from "../timeline.js";

const mk = (canvas, repeat = true) => {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  t.anisotropy = 4;
  return t;
};

/** Lit-windows texture (used as emissive map for the tower + skyline). */
export function windowTexture(seed, cols, rows, litProb) {
  const cw = 16, ch = 24;
  const c = document.createElement("canvas");
  c.width = cols * cw; c.height = rows * ch;
  const g = c.getContext("2d");
  g.fillStyle = "#000"; g.fillRect(0, 0, c.width, c.height);
  const palette = ["#ffcf8a", "#ffe9c4", "#cfeeff", "#37e8ff", "#9fd8ff"];
  for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
    const r = rnd(seed + x * 13.1 + y * 71.7);
    if (r < litProb) {
      g.globalAlpha = 0.35 + rnd(seed * 3 + x + y * 9) * 0.65;
      g.fillStyle = palette[Math.floor(rnd(seed + x * 5 + y * 3) * palette.length)];
      g.fillRect(x * cw + 3, y * ch + 5, cw - 6, ch - 11);
    }
  }
  g.globalAlpha = 1;
  return mk(c);
}

export function radialGlow(inner = "rgba(120,240,255,1)", mid = "rgba(40,200,255,0.35)") {
  const c = document.createElement("canvas"); c.width = c.height = 256;
  const g = c.getContext("2d");
  const gr = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  gr.addColorStop(0, inner); gr.addColorStop(0.5, mid); gr.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  return mk(c, false);
}

/** Soft cloud noise for volumetric fog layers. */
export function fogTexture(seed) {
  const c = document.createElement("canvas"); c.width = c.height = 512;
  const g = c.getContext("2d");
  g.fillStyle = "#000"; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 90; i++) {
    const x = rnd(seed + i * 3.3) * 512, y = rnd(seed + i * 7.7) * 512, r = 40 + rnd(seed + i * 1.9) * 120;
    for (const [ox, oy] of [[0, 0], [-512, 0], [512, 0], [0, -512], [0, 512]]) {
      const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, r);
      gr.addColorStop(0, "rgba(255,255,255,0.22)"); gr.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = gr; g.fillRect(x + ox - r, y + oy - r, r * 2, r * 2);
    }
  }
  return mk(c);
}

export function skyTexture() {
  const c = document.createElement("canvas"); c.width = 16; c.height = 512;
  const g = c.getContext("2d");
  const gr = g.createLinearGradient(0, 0, 0, 512);
  gr.addColorStop(0, "#010208"); gr.addColorStop(0.55, "#04101c"); gr.addColorStop(0.8, "#0a2a3c"); gr.addColorStop(0.9, "#1a4a5c"); gr.addColorStop(1, "#02060a");
  g.fillStyle = gr; g.fillRect(0, 0, 16, 512);
  return mk(c, false);
}

export function streetsTexture() {
  const c = document.createElement("canvas"); c.width = c.height = 1024;
  const g = c.getContext("2d");
  g.fillStyle = "#020509"; g.fillRect(0, 0, 1024, 1024);
  for (let i = 0; i < 16; i++) {
    const p = i * 64 + 30;
    g.fillStyle = "rgba(255,190,120,0.55)"; g.fillRect(0, p, 1024, 3); g.fillRect(p, 0, 3, 1024);
    for (let k = 0; k < 60; k++) { g.fillStyle = rnd(i * 60 + k) > 0.5 ? "#ffd9a0" : "#37e8ff"; g.fillRect(rnd(i + k * 3) * 1024, p, 4, 3); g.fillRect(p, rnd(i * 5 + k) * 1024, 3, 4); }
  }
  return mk(c);
}

export function withRepeat(tex, rx, ry) {
  const t = tex.clone();
  t.needsUpdate = true;
  t.repeat.set(rx, ry);
  return t;
}
