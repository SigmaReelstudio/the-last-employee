import React, { useMemo } from "react";
import * as THREE from "three";
import { EffectComposer, Bloom, Vignette, Noise, ToneMapping, DepthOfField, ChromaticAberration, BrightnessContrast, HueSaturation } from "@react-three/postprocessing";
import { BlendFunction, ToneMappingMode } from "postprocessing";

// Post-processing: rack-focus DOF -> soft bloom -> glitch chromatic aberration -> ACES filmic tone
// mapping -> filmic contrast / cold grade -> film grain -> vignette.
export default function Effects({ state }) {
  const { bloom, glitch, rack } = state;
  const ca = useMemo(() => new THREE.Vector2(0, 0), []);
  ca.set(glitch * 0.012, glitch * 0.004);
  return (
    <EffectComposer multisampling={4} disableNormalPass>
      {rack ? (
        <DepthOfField
          // react-postprocessing expects normalized focusDistance/focalLength,
          // not worldFocusDistance/worldFocusRange. Map the authored metre-like
          // timeline values into a conservative normalized camera range.
          focusDistance={Math.min(0.95, Math.max(0.02, rack.focus / 30))}
          focalLength={Math.min(0.12, Math.max(0.015, rack.range / 45))}
          bokehScale={5}
        />
      ) : null}
      <Bloom intensity={bloom} luminanceThreshold={0.62} luminanceSmoothing={0.25} mipmapBlur radius={0.78} />
      <ChromaticAberration offset={ca} radialModulation={false} modulationOffset={0} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      <BrightnessContrast brightness={-0.015} contrast={0.16} />
      <HueSaturation hue={0} saturation={-0.06} />
      <Noise opacity={0.055} blendFunction={BlendFunction.SOFT_LIGHT} />
      <Vignette eskil={false} offset={0.18} darkness={0.88} />
    </EffectComposer>
  );
}
