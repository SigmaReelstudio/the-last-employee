import { posAt, distAt, speedAt, STRIDE } from "./path.mjs";

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SEC = 85;
export const DURATION_FRAMES = FPS * DURATION_SEC;

export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, u) => a + (b - a) * u;
export const smooth = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
export const smoother = (x) => { x = clamp(x); return x * x * x * (x * (x * 6 - 15) + 10); };
export const linear = (x) => clamp(x);
export const rnd = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const mix = (a, b, u) => (Array.isArray(a) ? a.map((v, i) => lerp(v, b[i], u)) : lerp(a, b, u));

/** Keyframe interpolation. keys = [[t, value], ...]; value is number or array. */
export function kf(t, keys, ease = smoother) {
  if (t <= keys[0][0]) return keys[0][1];
  const last = keys[keys.length - 1];
  if (t >= last[0]) return last[1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, v0] = keys[i], [t1, v1] = keys[i + 1];
    if (t >= t0 && t < t1) return mix(v0, v1, ease((t - t0) / (t1 - t0)));
  }
  return last[1];
}
export const kfl = (t, keys) => kf(t, keys, linear);

/** Smooth "pulse" that is 1 between a and b, ramping over r seconds. */
export const pulse = (t, a, b, r = 0.2) => smooth((t - a) / r) * (1 - smooth((t - b) / r));

// ---------------------------------------------------------------- scene layout (seconds)
export const SCENE_TIMES = {
  arrival: [0, 12],
  reveal: [12, 25],
  mystery: [25, 40],
  lightsOut: [40, 58],
  finalReveal: [58, 75],
  finalMessage: [75, 85],
};

// ---------------------------------------------------------------- world constants
export const FIXTURES = [
  [-1.8, 4.0], [1.8, 4.0], [-1.8, -0.8], [1.8, -0.8], [-1.8, -5.2], [1.8, -5.2],
  [0, -3.0], // hero fixture (index 6) - the ring that "appears"
];
export const LIGHT_OFF_TIMES = [41.0, 42.4, 43.8, 45.2, 46.8, 48.4]; // fixtures 0..5 switch off in sequence
export const HERO_RING_TIME = 46.0;

export function lightsAt(t) {
  const out = [];
  for (let i = 0; i < 6; i++) {
    const off = LIGHT_OFF_TIMES[i];
    let v = 1;
    if (t > off - 0.6) {
      // stutter before dying
      const s = (t - (off - 0.6)) / 0.6;
      const stutter = rnd(Math.floor(t * 30) + i * 17) > 0.45 ? 1 : 0.15;
      v = s < 1 ? stutter : 1 - smooth((t - off) / 0.25);
      if (t > off) v = 0;
    }
    out.push(v);
  }
  // hero light: dim until ring appears, then a pulsing cyan source
  const hero = 0.18 + 0.82 * smooth((t - HERO_RING_TIME) / 2.5);
  out.push(t > 74.2 ? hero * rnd(Math.floor(t * 30)) : hero);
  return out;
}

// ---------------------------------------------------------------- employee (global, continuous)
const PI = Math.PI;
const FACING = [
  [0, PI], [33.0, PI], [34.8, 0.0], [38.0, 0.0], [39.5, PI], [57.4, PI],
  [58.6, 2.5], [60.0, PI], [62.6, PI], [63.8, PI + 0.0],
];
const HEAD_YAW = [
  [0, 0], [17.5, 0], [18.4, 0.5], [20.2, 0.5], [21.0, -0.35], [21.9, -0.35], [22.6, 0],
  [27, 0], [28.0, 0.12], [29, 0], [61.0, 0], [62.0, 0.0],
];
const HEAD_PITCH = [[0, 0], [23.0, 0], [24.0, 0.18], [30, 0.18], [31.5, 0.0], [55.5, 0.0], [57.3, -0.22], [63, -0.22]];
const FEAR = [[0, 0], [30, 0], [33.4, 0.5], [35, 0.7], [38.5, 0.4], [41, 0.7], [55, 1], [62, 0.9], [75, 1]];

export function employeeAt(t) {
  const [x, z] = posAt(t);
  const speed = speedAt(t);
  const amp = clamp(speed / 0.9);
  return {
    visible: t >= 10.4,
    pos: [x, 0, z],
    rotY: kfl(t, FACING),
    walkPhase: (distAt(t) / (STRIDE * 2)) * Math.PI * 2,
    walkAmp: amp,
    headYaw: kf(t, HEAD_YAW) + Math.sin(t * 0.9) * 0.04,
    headPitch: kf(t, HEAD_PITCH) + Math.sin(t * 0.6 + 1) * 0.015,
    fear: kf(t, FEAR),
    blink: rnd(Math.floor(t * 2.5)) > 0.93 && (t * 2.5) % 1 < 0.12 ? 1 : 0,
    breath: Math.sin(t * 1.6),
  };
}

// ---------------------------------------------------------------- the silhouette ("the other one")
export const ENTITY_ALPHA = [
  [0, 0], [30.4, 0], [31.8, 1], [33.4, 1], [34.1, 0], [38.5, 0], [38.9, 1], [75, 1],
];
export const ENTITY_DIST = [[0, 3.6], [31, 3.6], [33.4, 3.2], [38.9, 1.9], [46, 1.5], [52, 1.0], [56, 0.6], [75, 0.5]];

export function entityAt(t) {
  const flick = t > 36.6 && t < 38.1 ? (rnd(Math.floor(t * 30)) > 0.5 ? 1 : 0.2) : 1;
  return { alpha: kf(t, ENTITY_ALPHA, linear) * flick, dist: kf(t, ENTITY_DIST) };
}

// ---------------------------------------------------------------- base (global) state
export function baseState(t) {
  const emp = employeeAt(t);
  const lights = lightsAt(t);

  // Glimpses of the 3D silhouette in the real room: only when a light stutters out
  let glimpse = 0;
  for (let i = 0; i < 6; i++) {
    const off = LIGHT_OFF_TIMES[i];
    if (t > off - 0.6 && t < off + 0.5) glimpse = Math.max(glimpse, 0.55 * (rnd(Math.floor(t * 30) + i) > 0.4 ? 1 : 0));
  }
  const ent = entityAt(t);

  // monitor interference events
  const flicker = Math.max(
    pulse(t, 24.0, 24.5, 0.05),
    pulse(t, 31.6, 32.0, 0.05),
    pulse(t, 36.6, 38.2, 0.05) * 0.8,
    ...LIGHT_OFF_TIMES.map((o) => pulse(t, o - 0.1, o + 0.4, 0.05) * 0.7),
    pulse(t, 53.6, 54.4, 0.05),
    pulse(t, 72.8, 74.4, 0.05) * (0.5 + 0.5 * rnd(Math.floor(t * 30))),
  );

  const heroFeed = t < 24.0 ? "ui" : t < 54.0 ? "feed" : "text";
  const otherFeed = t < 48.0 ? "ui" : "cams";

  return {
    t,
    emp,
    cam: { pos: [0, 1.7, 0], look: [0, 1.5, -5], fov: 45, roll: 0, shake: 0.5 },
    lights,
    cyan: kf(t, [[0, 0.8], [40, 0.9], [48, 1.7], [70, 2.1]]),
    fog: kf(t, [[0, 0.25], [12, 0.4], [40, 0.45], [58, 1.0], [75, 1.15]]),
    fogExp: kfl(t, [[0, 0.004], [9, 0.006], [11.5, 0.013], [40, 0.016], [58, 0.032], [75, 0.038]]),
    ringHero: smooth((t - HERO_RING_TIME) / 1.8),
    flicker,
    glitch: Math.max(flicker * 0.5, pulse(t, 33.9, 34.2, 0.05) * 0.4),
    blackout: t >= 74.5 ? 1 : 0,
    ghost: 0,
    mirrorEmp: 0,
    entity: ent,
    entity3d: glimpse * ent.alpha,
    feed: { hero: heroFeed, others: otherFeed, textStart: 54.0 },
    rack: null,
    bloom: 1.05,
    exposure: 1,
    exteriorLit: 1,
  };
}

/** Helper for scenes: camera relative to the employee */
export function relCam(b, off, lookOff) {
  const p = b.emp.pos;
  return {
    pos: [p[0] + off[0], off[1], p[2] + off[2]],
    look: [p[0] + lookOff[0], lookOff[1], p[2] + lookOff[2]],
  };
}
