// Narration cues (seconds). Used by the on-screen captions AND by scripts/generate-audio.mjs.
export const CUES = [
  { t: 2.4, text: "At two seventeen in the morning, the building is supposed to be empty." },
  { t: 9.6, text: "But someone always works the night shift." },
  { t: 16.0, text: "Every screen is already awake." },
  { t: 21.6, text: "As if they were waiting. For him." },
  { t: 27.0, text: "One monitor is showing the office. Live." },
  { t: 31.6, text: "And someone is standing right behind him." },
  { t: 41.6, text: "The lights begin to fail. One by one." },
  { t: 49.0, text: "Every camera. Every angle. Closer." },
  { t: 57.9, text: "He never asked who else had clocked in." },
  { t: 65.0, text: "Look at the window. Look at the reflection." },
  { t: 77.2, text: "Your shift has just begun." },
];
