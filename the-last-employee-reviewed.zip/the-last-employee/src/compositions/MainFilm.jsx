import React from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import * as THREE from "three";
import World from "../components/World.jsx";
import { baseState, WIDTH, HEIGHT, smooth } from "../timeline.js";
import { arrival } from "../scenes/Arrival.jsx";
import { reveal } from "../scenes/OfficeReveal.jsx";
import { mystery } from "../scenes/MonitorMystery.jsx";
import { lightsOut } from "../scenes/LightsOut.jsx";
import { finalReveal } from "../scenes/FinalReveal.jsx";
import { finalMessage } from "../scenes/FinalMessage.jsx";
import { CUES } from "../audio/narration.mjs";

const SCENES = [arrival, reveal, mystery, lightsOut, finalReveal, finalMessage];

export function stateAt(t) {
  const scene = SCENES.find((s) => t >= s.start && t < s.end) || finalMessage;
  const base = baseState(t);
  const over = scene.state(t, base);
  return { scene, state: { ...base, ...over, cam: { ...base.cam, ...(over.cam || {}) } } };
}

function Captions({ t }) {
  const cue = [...CUES].reverse().find((c) => t >= c.t);
  if (!cue || t > cue.t + 6.2 || t >= 74.4) return null;
  const a = smooth((t - cue.t) / 0.4) * (1 - smooth((t - cue.t - 4.8) / 0.6));
  return (
    <div style={{ position: "absolute", left: 90, right: 90, bottom: 250, textAlign: "center", opacity: a, color: "#e8fdff", fontFamily: "Helvetica, Arial, sans-serif", fontWeight: 300, fontSize: 42, lineHeight: 1.3, letterSpacing: 1.5, textShadow: "0 2px 14px #000, 0 0 22px rgba(25,227,255,0.55)" }}>
      {cue.text}
    </div>
  );
}

export const MainFilm = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const { scene, state } = stateAt(t);
  const showWorld = t < 74.5;
  const Overlay = scene.Overlay;
  const fadeIn = 1 - smooth(t / 1.2);

  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      {showWorld && (
        <ThreeCanvas
          width={WIDTH}
          height={HEIGHT}
          shadows
          camera={{ fov: 45, near: 0.05, far: 800, position: [0, 2, 0] }}
          gl={{ antialias: false, powerPreference: "high-performance", toneMapping: THREE.NoToneMapping }}
          style={{ width: WIDTH, height: HEIGHT }}
        >
          <World state={state} />
        </ThreeCanvas>
      )}
      <AbsoluteFill style={{ pointerEvents: "none" }}>
        <Overlay t={t} />
        <Captions t={t} />
      </AbsoluteFill>
      <AbsoluteFill style={{ backgroundColor: "#000", opacity: fadeIn, pointerEvents: "none" }} />
      {/* Audio: procedural score + SFX (fx.wav) and synthesized narration (narration.wav) */}
      <Audio src={staticFile("audio/fx.wav")} volume={1} />
      <Audio src={staticFile("audio/narration.wav")} volume={1} />
    </AbsoluteFill>
  );
};
