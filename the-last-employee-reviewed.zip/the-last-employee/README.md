# THE LAST EMPLOYEE — Remotion + Three.js cinematic short

1080 × 1920 (9:16) · 30 FPS · 85 s (2550 frames) · H.264 MP4 · original synthesized audio + narration.

> **Status:** the project was authored in a sandbox with no network, so Remotion / Three.js could not be
> installed there and **no MP4 has been rendered yet**. The timeline/camera/scene logic and audio were
> tested headlessly (no NaNs, all overlays render, audio generated). The 3D scene itself has NOT been
> run in a browser - expect to fix small things on first render. See "If something fails".

## Render it (exact commands)

Requirements: Node 18+ (20/22 recommended), ffmpeg on PATH (only needed to regenerate audio), a machine with a GPU
or a decent CPU. Chrome is downloaded automatically by Remotion on first render.

```bash
npm install
# (optional) regenerate the audio - already included in public/audio/
npm run audio

# live preview with scrubbing
npm run preview

# test a single frame first (frame 900 = 30 s)
npx remotion still src/index.jsx TheLastEmployee out/frame.png --frame=900 --gl=angle

# quick low-res check (540x960)
npm run render:preview

# FINAL 1080x1920 30fps MP4
npx remotion render src/index.jsx TheLastEmployee out/the-last-employee.mp4 --codec=h264 --crf=16 --gl=angle --concurrency=2 --timeout=120000
```
Output: `out/the-last-employee.mp4`.

On a machine without a GPU, WebGL is software-rendered: use `--concurrency=1`, lower `--scale`, or render
a frame range (`--frames=0-899`) and concatenate. 1080x1920 with bloom/fog is heavy; budget hours on CPU-only.

## What is where
```
src/index.jsx, Root.jsx            Remotion entry + <Composition> (1080x1920, 30fps, 2550 frames)
src/compositions/MainFilm.jsx      picks the scene by time, mounts the ThreeCanvas, captions, audio
src/timeline.js, path.mjs          all keyframes: employee walk, lights-out sequence, entity, FX state
src/scenes/*.jsx                   Arrival, OfficeReveal, MonitorMystery, LightsOut, FinalReveal, FinalMessage
src/components/                    Office, Employee (rigged character), Monitors (live canvas screens),
                                   Lighting (fixtures/rings/cones), Fog (+Dust), City, Camera, Effects, World
scripts/generate-audio.mjs         procedural score + SFX + TTS narration -> public/audio/*.wav
public/audio/fx.wav, narration.wav
```
Scene times: 1 Arrival 0-12 · 2 Something is wrong 12-25 · 3 The warning 25-40 · 4 Office changes 40-58 ·
5 The reveal 58-75 (hard blackout at 74.4 s) · 6 Final message 75-85.

## Features -> implementation (and substitutions)
| Requirement | Implementation |
|---|---|
| ACES tone mapping, bloom, grade | `postprocessing` ToneMapping(ACES_FILMIC) + Bloom (mipmapBlur) + contrast/saturation + grain + vignette (Effects.jsx) |
| Glossy reflective floor | **Substitute:** planar reflection shader needs `@react-three/drei`; instead the floor is a semi-transparent glossy PBR plane and emissive objects/the employee are rendered mirrored beneath it (Reflected.jsx) |
| Volumetric fog | **Substitute:** 6 drifting noise-texture slabs (normal + additive) + exponential scene fog + additive light cones |
| Floating dust | 650 deterministic additive points |
| Glowing floor rings | emissive ring + glow disc + rotating arcs under every ceiling light; the hero ring ignites at 46 s |
| Employee + silhouette | primitive-built humanoid with walk cycle, head turns, blinking brows/eyes ("fear" expression), seated pose |
| Camera feed on the monitor | **Substitute:** monitors are live 2D-canvas textures drawn per frame (not a second 3D render target) |
| Window reflection | **Substitute:** a cyan additive "ghost" copy placed behind the glass (mirror of the desk + seated figure) |
| Rack focus | DepthOfField with animated world focus distance (only active during rack-focus moments) |
| Audio | fully synthesized (Node, no deps): drone, ambience, footsteps synced to the walk path, electrical buzz as lights die, monitor interference, pulses, riser, impacts, **sudden silence 70.45-74.38 s**, final boom |
| Narration | **Substitute:** offline TTS (ffmpeg `flite`, pitched down + reverb). It is robotic - for a professional read, replace `public/audio/narration.wav` (85 s, 44.1 kHz) with your own voice-over; cues/timings are in `src/audio/narration.mjs` |

## If something fails
* Version mismatch errors: all `remotion` / `@remotion/*` packages must be the same version -> `npx remotion upgrade`.
* `@react-three/postprocessing` / `postprocessing` peer errors: keep `three@0.169.0`, `@react-three/fiber@8`, `react@18`.
* Black/empty frames: render with `--gl=angle` (already in scripts); try `--gl=swangle` on machines without a GPU.
* Too slow / out of memory: lower `multisampling` in `Effects.jsx` to 0, drop `shadows` in `MainFilm.jsx`, or use `--scale=0.75`.
* DepthOfField issues: delete the `<DepthOfField .../>` line in `Effects.jsx` (rack focus will simply be skipped).


## Review / compatibility repair (2026-11-09)

A static source review was performed on the delivered archive.

- Fixed the rack-focus DepthOfField props in `src/components/Effects.jsx`: the original used `worldFocusDistance` / `worldFocusRange`, which are not the standard `@react-three/postprocessing` props. The project now maps the authored focus values to `focusDistance` / `focalLength`.
- Parsed all 24 `.js`, `.jsx`, and `.mjs` source files with the installed TypeScript parser: no syntax diagnostics.
- Checked all relative source imports: no missing local imports.
- Checked both bundled WAV files with `ffprobe`: each is 85 seconds, matching the composition duration.
- Checked the Remotion composition settings: 1080 × 1920, 30 FPS, 2550 frames.

**Not verified:** This environment does not contain `node_modules` and has no package-install network access. Therefore Remotion/Three.js could not be launched, and neither a browser preview nor a rendered first frame / MP4 could be produced here. The DepthOfField correction is a source-level compatibility repair, not proof of a successful browser render.
